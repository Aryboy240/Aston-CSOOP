package uk.ac.aston.oop.dpatterns.fmethod;

public class Snippet {
	public static void main(String[] args) {
		uk.ac.aston.oop.dpatterns.fmethod
	}
}

