/**
 * Utilities to support testing the inheritance lab program.
 *
 * @author Antonio Garcia-Dominguez
 * @version 1.0
 */

package uk.ac.aston.oop.inheritance.util;